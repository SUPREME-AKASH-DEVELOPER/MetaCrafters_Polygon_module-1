const hre = require("hardhat");
const tokenContractJSON = require("../artifacts/contracts/StreetNft.sol/StreetNft.json");

const tokenAddress = "0xF51f0A0Ff6A99Abc416F57450c1c6D0e6d63eB5a"; 
const tokenABI = tokenContractJSON.abi;
const walletAddress = "0x6a6C7a52765083a029e77D4C5CC81A17dCe120f1";

async function main() {

    const token = await hre.ethers.getContractAt(tokenABI, tokenAddress);
    const balance = await token.balanceOf(walletAddress);
    console.log(`You now have: ${balance} NFTs in your wallet`);
  }
  main().catch((error) => {
    console.error(error);
    process.exitCode = 1;
  });